<?php
class Area {
    public $id;
    public $name;
    public $council_id;
    public $created_at;
}