<?php
class Company {
    public $id;
    public $name;
    public $contact_info;
    public $created_at;
}