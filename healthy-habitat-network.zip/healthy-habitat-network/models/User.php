<?php
class User {
    public $id;
    public $username;
    public $email;
    public $location;
    public $age_group;
    public $gender;
    public $interests;
}