<?php
class Product {
    public $id;
    public $name;
    public $description;
    public $size_quantity;
    public $health_benefits;
    public $price_category;
    public $company_id;
    public $certifications;
}