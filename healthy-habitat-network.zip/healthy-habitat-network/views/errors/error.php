<div class="alert alert-danger">
    <strong>Error!</strong> <?php echo htmlspecialchars($error); ?>
</div>